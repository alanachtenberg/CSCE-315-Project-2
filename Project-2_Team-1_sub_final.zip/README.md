Project-2_Team-1
=======================
Five in a row online, game engine and server in c++ and gui client in java

Team Members - Group 1
=========================
Robert Grathwohl
Casey Brooks
Alan Achtenberg
Jacob Stone

Compilation Instructions
=========================
1) At the root of the project directory src, type 'make' to compile
2) Program can be executed with 'make run'
3) In another linux terminal in the Linux server, type 'telnet localhost 2323'
4) PASSWORD is aquafina
5) Proceed with playing the game with commands '[hex][hex]' 'UNDO', 'REDO', 'DISPLAY', and 'EXIT'


Compilation Instructions For GUI
=========================
1) At the root of the project directory client_src, type 'make' to compile
2) Program can be executed with 'make run'
3) PASSWORD is aquafina
Turn-Ins
=========================
This weeks backlog is saved in the file 'SCRUM backlog week 1.xlsb'.
This weeks burndown chart is saved in the file "SCRUM burndown chart week 1.xlsb'.
